import csv
import os

# --- MÓDULO DE ARCHIVOS Y CARGA DE DATOS ---

def cargar_datos_csv(nombre_archivo):
    """Lee el archivo CSV y retorna una lista de diccionarios con los países."""
    paises = []
    if not os.path.exists(nombre_archivo):
        print(f"[Aviso] El archivo '{nombre_archivo}' no existe. Se iniciará con una lista vacía.")
        return paises
    
    try:
        with open(nombre_archivo, mode='r', encoding='utf-8') as archivo:
            lector = csv.DictReader(archivo)
            for fila in lector:
                # Validar y convertir tipos de datos numéricos
                pais = {
                    "nombre": fila["nombre"].strip(),
                    "poblacion": int(fila["poblacion"].strip()),
                    "superficie": int(fila["superficie"].strip()),
                    "continente": fila["continente"].strip()
                }
                paises.append(pais)
        print(f"[Éxito] Se cargaron {len(paises)} países correctamente desde el archivo.")
    except Exception as e:
        print(f"[Error] Hubo un problema al leer el archivo CSV: {e}")
    return paises

def guardar_datos_csv(nombre_archivo, paises):
    """Guarda la lista actual de países en el archivo CSV."""
    try:
        with open(nombre_archivo, mode='w', newline='', encoding='utf-8') as archivo:
            fieldnames = ["nombre", "poblacion", "superficie", "continente"]
            escritor = csv.DictWriter(archivo, fieldnames=fieldnames)
            escritor.writeheader()
            for pais in paises:
                escritor.writerow(pais)
    except Exception as e:
        print(f"[Error] No se pudo guardar en el archivo: {e}")

# --- MÓDULO DE FUNCIONALIDADES (REQUERIMIENTOS) ---

def agregar_pais(paises):
    """Agrega un país validando que no existan campos vacíos y formatos correctos."""
    print("\n--- AGREGAR NUEVO PAÍS ---")
    nombre = input("Ingrese el nombre del país: ").strip()
    if not nombre:
        print("[Error] El nombre no puede estar vacío.")
        return

    # Validar población
    try:
        poblacion = int(input("Ingrese la población (entero): "))
        if poblacion < 0:
            print("[Error] La población debe ser un número positivo.")
            return
    except ValueError:
        print("[Error] Debe ingresar un número entero válido para la población.")
        return

    # Validar superficie
    try:
        superficie = int(input("Ingrese la superficie en km² (entero): "))
        if superficie < 0:
            print("[Error] La superficie debe ser un número positivo.")
            return
    except ValueError:
        print("[Error] Debe ingresar un número entero válido para la superficie.")
        return

    continente = input("Ingrese el continente: ").strip()
    if not continente:
        print("[Error] El continente no puede estar vacío.")
        return

    nuevo_pais = {
        "nombre": nombre,
        "poblacion": poblacion,
        "superficie": superficie,
        "continente": continente
    }
    
    paises.append(nuevo_pais)
    guardar_datos_csv("paises.csv", paises)
    print(f"[Éxito] ¡País '{nombre}' agregado exitosamente!")

def actualizar_pais(paises):
    """Actualiza la población y superficie de un país existente buscando por nombre."""
    print("\n--- ACTUALIZAR DATOS DE UN PAÍS ---")
    if not paises:
        print("[Aviso] No hay países cargados.")
        return

    busqueda = input("Ingrese el nombre del país a actualizar: ").strip().lower()
    encontrados = [p for p in paises if busqueda in p["nombre"].lower()]

    if not encontrados:
        print("[Aviso] No se encontró ningún país con ese nombre.")
        return

    print("Países encontrados:")
    for i, p in enumerate(encontrados):
        print(f"{i + 1}. {p['nombre']} ({p['continente']})")

    try:
        seleccion = int(input("Seleccione el número del país que desea actualizar: ")) - 1
        if seleccion < 0 or seleccion >= len(encontrados):
            print("[Error] Selección inválida.")
            return
    except ValueError:
        print("[Error] Debe ingresar un número.")
        return

    pais_a_modificar = encontrados[seleccion]

    try:
        nueva_pob = int(input(f"Nueva población para {pais_a_modificar['nombre']} (Actual: {pais_a_modificar['poblacion']}): "))
        nueva_sup = int(input(f"Nueva superficie para {pais_a_modificar['nombre']} (Actual: {pais_a_modificar['superficie']}): "))
        
        pais_a_modificar["poblacion"] = nueva_pob
        pais_a_modificar["superficie"] = nueva_sup
        
        guardar_datos_csv("paises.csv", paises)
        print("[Éxito] Datos actualizados correctamente.")
    except ValueError:
        print("[Error] Los valores ingresados deben ser números enteros.")

def buscar_pais(paises):
    """Busca un país por coincidencia parcial o exacta en su nombre."""
    print("\n--- BUSCAR PAÍS ---")
    if not paises:
        print("[Aviso] No hay países cargados.")
        return

    query = input("Ingrese el nombre o parte del nombre a buscar: ").strip().lower()
    resultados = [p for p in paises if query in p["nombre"].lower()]

    if resultados:
        print(f"\nSe encontraron {len(resultados)} coincidencia(s):")
        print(f"{'Nombre':<15} | {'Población':<12} | {'Superficie (km²)':<16} | {'Continente':<10}")
        print("-" * 63)
        for p in resultados:
            print(f"{p['nombre']:<15} | {p['poblacion']:<12} | {p['superficie']:<16} | {p['continente']:<10}")
    else:
        print("[Aviso] No se encontraron países que coincidan con la búsqueda.")

def filtrar_paises(paises):
    """Submenú para filtrar países por continente, rango de población o superficie."""
    print("\n--- FILTRAR PAÍSES ---")
    print("1. Filtrar por Continente")
    print("2. Filtrar por Rango de Población")
    print("3. Filtrar por Rango de Superficie")
    opcion = input("Elija una opción de filtro: ").strip()

    resultados = []

    if opcion == "1":
        cont = input("Ingrese el continente: ").strip().lower()
        resultados = [p for p in paises if p["continente"].lower() == cont]
    elif opcion == "2":
        try:
            min_pob = int(input("Población mínima: "))
            max_pob = int(input("Población máxima: "))
            resultados = [p for p in paises if min_pob <= p["poblacion"] <= max_pob]
        except ValueError:
            print("[Error] Ingrese valores numéricos válidos.")
            return
    elif opcion == "3":
        try:
            min_sup = int(input("Superficie mínima: "))
            max_sup = int(input("Superficie máxima: "))
            resultados = [p for p in paises if min_sup <= p["superficie"] <= max_sup]
        except ValueError:
            print("[Error] Ingrese valores numéricos válidos.")
            return
    else:
        print("[Error] Opción de filtro inválida.")
        return

    if resultados:
        print(f"\nResultados del filtro ({len(resultados)} países):")
        print(f"{'Nombre':<15} | {'Población':<12} | {'Superficie (km²)':<16} | {'Continente':<10}")
        print("-" * 63)
        for p in resultados:
            print(f"{p['nombre']:<15} | {p['poblacion']:<12} | {p['superficie']:<16} | {p['continente']:<10}")
    else:
        print("[Aviso] No hay países que cumplan con los criterios especificados.")

def ordenar_paises(paises):
    """Submenú para ordenar países por nombre, población o superficie (asc/desc)."""
    print("\n--- ORDENAR PAÍSES ---")
    print("1. Ordenar por Nombre")
    print("2. Ordenar por Población")
    print("3. Ordenar por Superficie")
    opcion = input("Elija criterio de ordenamiento: ").strip()

    if opcion not in ["1", "2", "3"]:
        print("[Error] Opción inválida.")
        return

    sentido = input("¿Desea orden ascendente (1) o descendente (2)? ").strip()
    reverse = True if sentido == "2" else False

    if opcion == "1":
        lista_ordenada = sorted(paises, key=lambda x: x["nombre"], reverse=reverse)
    elif opcion == "2":
        lista_ordenada = sorted(paises, key=lambda x: x["poblacion"], reverse=reverse)
    elif opcion == "3":
        lista_ordenada = sorted(paises, key=lambda x: x["superficie"], reverse=reverse)

    print(f"\nPaíses ordenados:")
    print(f"{'Nombre':<15} | {'Población':<12} | {'Superficie (km²)':<16} | {'Continente':<10}")
    print("-" * 63)
    for p in lista_ordenada:
        print(f"{p['nombre']:<15} | {p['poblacion']:<12} | {p['superficie']:<16} | {p['continente']:<10}")

def mostrar_estadisticas(paises):
    """Calcula y muestra estadísticas del dataset."""
    print("\n--- ESTADÍSTICAS DEL SISTEMA ---")
    if not paises:
        print("[Aviso] No hay datos disponibles para generar estadísticas.")
        return

    # Máxima y mínima población
    pais_max_pob = max(paises, key=lambda x: x["poblacion"])
    pais_min_pob = min(paises, key=lambda x: x["poblacion"])

    # Promedios
    total_poblacion = sum(p["poblacion"] for p in paises)
    total_superficie = sum(p["superficie"] for p in paises)
    cant_paises = len(paises)

    prom_poblacion = total_poblacion / cant_paises
    prom_superficie = total_superficie / cant_paises

    # Conteo por continente
    conteo_continentes = {}
    for p in paises:
        cont = p["continente"]
        conteo_continentes[cont] = conteo_continentes.get(cont, 0) + 1

    print(f"• Mayor población: {pais_max_pob['nombre']} ({pais_max_pob['poblacion']:,} hab.)")
    print(f"• Menor población: {pais_min_pob['nombre']} ({pais_min_pob['poblacion']:,} hab.)")
    print(f"• Promedio de población: {prom_poblacion:,.2f} hab.")
    print(f"• Promedio de superficie: {prom_superficie:,.2f} km²")
    print("\n• Cantidad de países por continente:")
    for cont, cantidad in conteo_continentes.items():
        print(f"  - {cont}: {cantidad} país(es)")

# --- MENÚ PRINCIPAL ---

def main():
    archivo = "paises.csv"
    paises = cargar_datos_csv(archivo)

    while True:
        print("\n========================================")
        print("   GESTIÓN DE DATOS DE PAÍSES - MENÚ")
        print("========================================")
        print("1. Agregar un país")
        print("2. Actualizar datos de un país")
        print("3. Buscar un país por nombre")
        print("4. Filtrar países")
        print("5. Ordenar países")
        print("6. Mostrar estadísticas")
        print("7. Salir")
        
        opcion = input("\nSeleccione una opción (1-7): ").strip()

        if opcion == "1":
            agregar_pais(paises)
        elif opcion == "2":
            actualizar_pais(paises)
        elif opcion == "3":
            buscar_pais(paises)
        elif opcion == "4":
            filtrar_paises(paises)
        elif opcion == "5":
            ordenar_paises(paises)
        elif opcion == "6":
            mostrar_estadisticas(paises)
        elif opcion == "7":
            print("\n¡Gracias por utilizar el sistema de gestión de países! Saliendo...")
            break
        else:
            print("[Error] Opción no válida. Por favor, ingrese un número del 1 al 7.")

if __name__ == "__main__":
    main()